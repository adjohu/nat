from pathlib import Path
import hashlib,json,tarfile,subprocess,shutil
r=Path(__file__).resolve().parent;n=Path('/tmp/nat-sparse-024');out=n/'research/compiler-paths-025';out.mkdir(parents=True,exist_ok=True)
checks=json.loads((r/'verification.json').read_text());assert len(checks)==7 and all(x['exit_status']==0 for x in checks)
assert 'FAILED' not in (r/'root-package-tests.log').read_text()
rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=n,text=True).strip();build=json.loads((r/'build-3/result.json').read_text());summary={'compiler_revision':rev,'default_generated_tests':26,'canonical_generated_tests':26,'prior_cli_tests':6,'independent_reuse_tests':12,'root_package_tests_passed':True,'clippy_warnings_denied_passed':True,'installed_binary_changed':False,'model_compilations':1,'instrumentation_only_failed_launches':2,'build':build,'verification':checks}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'REPORT.txt').write_text(f'''Nat filesystem identity acceptance — 025, 2026-10-08

Compiler source/runtime revision: {rev}.
Includes verified-reuse parent b4ed696, based on original main cd4d62c.

Fixed the generated tests' macOS /var versus /private/var path-spelling defect
through spec/self-hosting.nat and ordinary scoped regeneration. Compare resolved
existing filesystem locations, preserve containment/escape checks, and exercise both
inherited and canonical temporary roots. The generated compiler executable source
files did not change in this fix; tests, documentation and build metadata changed.
No generated implementation was repaired manually.

Validation passed:
- 15 unit and 11 CLI tests (26 total) under inherited TMPDIR=/var/folders/.../T/.
- The same 26 tests under TMPDIR=/private/tmp.
- New retained-response alias and negative-containment acceptance.
- All six original CLI tests, plus 12 independent reuse/refusal fixtures.
- Clippy --all-targets with warnings denied.
- Repository-root cargo test --offline --no-fail-fast (15 unit plus six CLI tests).
- Nat source/artifact currency.
No live cognitive evaluation or external provider fixture calls were made.

The cumulative compiler change permits interpreter-resolved reuse of verified prior
file bytes in complete full-build inventories and explicitly rejects incomplete
results before replacing generated/inferred output. Prior independent real-artifact
replay reconstructed all 68 Brain outputs exactly with 57 reused files and a 32.7%
smaller JSON response. That is an offline encoding result, not a live speedup claim.
See nat-brain research/semantic-actions-024 for that pinned evidence.

This fix used one scoped model compilation: one changed specification, four affected
generated files, 376.28 seconds, 210,397 input tokens including 158,848 cached input,
20,953 output tokens (reported reasoning output 2,812). The earlier two launches
failed in the measurement wrapper before invoking a model; they cost no model calls.
The wrapper assumed exec was argv[0]; it now preserves global flags before exec.
The second launch repeated that failure because an attempted wrapper edit used the
wrong working directory. Both failed logs are retained. Controlled offline fixtures
verify old/new argv forms, usage recording and candidate preservation.

The installed ~/.cargo/bin/nat is unchanged. This report supports source merge,
not a claim that a local installation was replaced or live compilation became faster.
All original guard/refusal and scoped/legacy acceptance remains tested. No scope
was narrowed merely to produce an incremental build.

Archive: excludes the copied pre-build executable, Python bytecode, symlinks and
Cargo caches. Source revision and executable hash are recorded instead. Includes
compiler response/events/schema, failure logs, fixtures and validation evidence.
ARTIFACTS.json verifies each archived regular file and the complete archive hash.
''')
for f in ['REPORT.txt','summary.json','measurement-verification.json','provenance.json']:
 shutil.copy2(r/f,out/f)
files=[p for p in sorted(r.rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='nat-before' and not {'target','__pycache__'}.intersection(p.relative_to(r).parts) and p.suffix!='.pyc'];manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};archive=out/'artifacts.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=[m for m in t.getmembers() if m.isfile()];assert len(members)==len(manifest)
 for m in members:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name]
v={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(manifest),'all_member_hashes_verified':True,'files':manifest};(out/'ARTIFACTS.json').write_text(json.dumps(v,indent=2)+'\n');print({k:v for k,v in v.items() if k!='files'})
