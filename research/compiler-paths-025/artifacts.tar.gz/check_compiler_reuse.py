"""Independent offline CLI fixtures for full-build reuse; no provider calls."""
import pathlib,subprocess,json,tempfile,sys,os,hashlib,copy
binary=str(pathlib.Path(sys.argv[1]).resolve());out=pathlib.Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
results=[]
def snapshot(root):
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('generated','inferred') for p in (root/d).rglob('*') if p.is_file()}
def invoke(root,args,env=None):
 p=subprocess.run([binary,*args],cwd=root,env=env,text=True,capture_output=True,timeout=45)
 with (out/'commands.jsonl').open('a') as f:f.write(json.dumps({'root':str(root),'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n')
 return p
base={'summary':'two outputs','requirements':[{'id':'R1','source':'a.nat','statement':'Print hello.'}],'assumptions':[],'files':[{'path':'main.py','content':"print('hello')\n",'sources':['a.nat']},{'path':'keep.txt','content':'exact retained bytes\n','sources':['a.nat']}],'run':['python3','main.py'],'checks':[['python3','main.py']]}
def setup(name):
 r=out/name;r.mkdir();(r/'spec').mkdir();(r/'spec/a.nat').write_text('Print hello.\n')
 (r/'seed.json').write_text(json.dumps(base));p=invoke(r,['build','--proposal','seed.json']);assert p.returncode==0,p.stderr
 return r
def proposal(root,v):
 (root/'proposal.json').write_text(json.dumps(v));return invoke(root,['build','--full','--proposal','proposal.json'])
def record(name,fn):
 try:fn();results.append({'test':name,'passed':True})
 except Exception as e:results.append({'test':name,'passed':False,'error':repr(e)})
 (out/'result.json').write_text(json.dumps(results,indent=2)+'\n')
def positive():
 r=setup('positive');inode=(r/'generated/keep.txt').stat().st_ino
 v=copy.deepcopy(base);v.update(status='complete',diagnostic='');v['files'][1]['content']=None;v['files'][0]['content']="print('updated')\n"
 (r/'spec/a.nat').write_text('Print updated.\n');p=proposal(r,v);assert p.returncode==0,p.stderr
 assert (r/'generated/keep.txt').stat().st_ino==inode
 assert invoke(r,['check']).returncode==0
 assert invoke(r,['test']).returncode==0
 for f in v['files']:f['content']=None
 (r/'spec/a.nat').write_text('Print updated with unchanged implementation.\n');p=proposal(r,v);assert p.returncode==0,p.stderr
 assert invoke(r,['check']).returncode==0
record('mixed_and_all_reuse',positive)
def reject(name,mutate):
 r=setup(name);v=copy.deepcopy(base);v.update(status='complete',diagnostic='');v['files'][1]['content']=None
 mutate(r,v);before=snapshot(r);p=proposal(r,v);assert p.returncode!=0,p.stdout;assert snapshot(r)==before,'changed prior artifacts'
record('incomplete_placeholder',lambda:reject('incomplete',lambda r,v:v.update(status='incomplete',diagnostic='Cannot finish',files=[{'path':'diagnostic.txt','content':'unfinished','sources':['a.nat']}])) )
record('untracked_reuse',lambda:reject('untracked',lambda r,v:(r.joinpath('generated/untracked.txt').write_text('untracked'),v['files'][1].update(path='untracked.txt'))))
record('wrong_case',lambda:reject('case',lambda r,v:v['files'][1].update(path='KEEP.txt')))
record('duplicate_path',lambda:reject('duplicate',lambda r,v:v['files'].append(copy.deepcopy(v['files'][1]))))
record('edited_prior_bytes',lambda:reject('edited',lambda r,v:r.joinpath('generated/keep.txt').write_text('tampered')))
record('removed_prior_file',lambda:reject('removed',lambda r,v:r.joinpath('generated/keep.txt').unlink()))
def link(r,v):
 r.joinpath('outside.txt').write_text('exact retained bytes\n');r.joinpath('generated/keep.txt').unlink();r.joinpath('generated/keep.txt').symlink_to(r/'outside.txt')
record('symlink_reuse',lambda:reject('symlink',link))
def fresh():
 r=out/'fresh';r.mkdir();(r/'spec').mkdir();(r/'spec/a.nat').write_text('Print hello.\n');v=copy.deepcopy(base);v.update(status='complete',diagnostic='');v['files'][1]['content']=None
 before=snapshot(r);p=proposal(r,v);assert p.returncode!=0;assert snapshot(r)==before
record('fresh_reuse_refused',fresh)
def model_case(name,change_source=False,incomplete=False):
 r=setup(name);(r/'spec/a.nat').write_text('Updated source.\n');v=copy.deepcopy(base);v.update(status='incomplete' if incomplete else 'complete',diagnostic='deliberately incomplete' if incomplete else '');v['files'][1]['content']=None
 if incomplete:v['files']=[{'path':'diagnostic.txt','content':'not a program','sources':['a.nat']}]
 (r/'response.json').write_text(json.dumps(v));b=r/'bin';b.mkdir()
 script='''#!/usr/bin/env python3
import sys,json,pathlib
args=sys.argv;sys.stdin.read()
schema=json.loads(pathlib.Path(args[args.index('--output-schema')+1]).read_text());pathlib.Path('seen-schema.json').write_text(json.dumps(schema))
CHANGE
pathlib.Path(args[args.index('-o')+1]).write_text(pathlib.Path('response.json').read_text())
'''.replace('CHANGE',"pathlib.Path('spec/a.nat').write_text('Changed while compiling\\n')" if change_source else '')
 (b/'codex').write_text(script);(b/'codex').chmod(0o755);env=dict(os.environ);env['PATH']=str(b)+os.pathsep+env['PATH'];before=snapshot(r)
 prior_paths={str(p) for p in r.rglob('*') if p.is_file()}
 p=invoke(r,['build','--full'],env);schema=json.loads((r/'seen-schema.json').read_text());assert 'status' in schema['required']
 if change_source or incomplete:assert p.returncode!=0,p.stdout;assert snapshot(r)==before
 else:assert p.returncode==0,p.stderr;assert invoke(r,['check']).returncode==0
 if incomplete:
  retained=[]
  for q in r.rglob('*'):
   if q.is_file() and str(q) not in prior_paths and 'generated' not in q.relative_to(r).parts and 'inferred' not in q.relative_to(r).parts:
    try:
     if json.loads(q.read_text())==v:retained.append(str(q))
    except (ValueError,UnicodeError):pass
  assert retained,'Rejected response not retained outside generated/inferred'
record('actual_model_protocol_reuse',lambda:model_case('model'))
record('source_race_refused',lambda:model_case('race',change_source=True))
record('actual_model_incomplete_refused',lambda:model_case('model-incomplete',incomplete=True))
print(json.dumps(results,indent=2));sys.exit(not all(x['passed'] for x in results))
