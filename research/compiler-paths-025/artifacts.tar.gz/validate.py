import pathlib,json,time,subprocess,os,sys
r=pathlib.Path(__file__).resolve().parent;n=pathlib.Path('/tmp/nat-sparse-024');results=[]
while not (r/'build-3/result.json').exists():time.sleep(10)
v=json.loads((r/'build-3/result.json').read_text())
if v['exit_status']:raise SystemExit('Build failed; validation unrun')
commands=[('currency',[str(r/'nat-before'),'check'],n,{}),('default-tests',['cargo','test','--offline','--no-fail-fast'],n/'generated',{}),('canonical-tests',['cargo','test','--offline','--no-fail-fast'],n/'generated',{'TMPDIR':'/private/tmp'}),('clippy',['cargo','clippy','--offline','--all-targets','--','-D','warnings'],n/'generated',{}),('binary',['cargo','build','--offline'],n/'generated',{}),('prior-parity',['cargo','test','--offline','--no-fail-fast'],r.parent/'semantic-actions-024/compiler-parity',{}),('independent-reuse',[sys.executable,str(r/'check_compiler_reuse.py'),str(n/'generated/target/debug/nat'),str(r/'reuse-fixtures')],r,{})]
for name,cmd,cwd,extra in commands:
 start=time.monotonic();env=dict(os.environ);env.update(extra)
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'env_overrides':extra,'TMPDIR':env.get('TMPDIR'),'exit_status':p.returncode,'seconds':time.monotonic()-start});(r/'verification.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
 if name=='binary' and p.returncode:break
