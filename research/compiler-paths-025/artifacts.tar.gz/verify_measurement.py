from pathlib import Path
import tempfile,subprocess,os,json,sys
root=Path(__file__).resolve().parent;results=[]
for name,prefix in [('plain',[]),('global',['-c','approval_policy="never"'])]:
 with tempfile.TemporaryDirectory(dir=root) as temp:
  p=Path(temp);b=p/'bin';b.mkdir();fake=b/'codex';fake.write_text('#!'+sys.executable+'\nimport sys,json,pathlib\na=sys.argv[1:]\npathlib.Path(a[a.index("-o")+1]).write_text(json.dumps({"files":[]}))\nprint(json.dumps({"type":"turn.completed","usage":{"input_tokens":3,"output_tokens":2}}))\n');fake.chmod(0o755)
  nat=p/'nat';nat.write_text('#!'+sys.executable+'\nimport sys,subprocess,pathlib\nif sys.argv[1]=="check":sys.exit(1)\np=pathlib.Path(__file__).parent\n(p/"schema.json").write_text("{}")\nsys.exit(subprocess.run(["codex",*'+repr(prefix)+',"exec","--output-schema",str(p/"schema.json"),"-o",str(p/"candidate.json"),"-"],input="fixture",text=True).returncode)\n');nat.chmod(0o755)
  env=dict(os.environ);env['PATH']=str(b)+os.pathsep+env['PATH'];out=p/'result'
  c=subprocess.run([sys.executable,str(root.parents[1]/'tools/measure_nat_build.py'),'--nat',str(nat),'--log-dir',str(out)],env=env,capture_output=True,text=True);assert c.returncode==0,c.stderr
  inv=next(out.glob('invocation-*'));v=json.loads((inv/'input.json').read_text());a=v['argv'];assert a[:len(prefix)]==prefix and a[a.index('exec')+1]=='--json';assert (inv/'candidate.json').is_file();assert json.loads((inv/'result.json').read_text())['usage']==[{'input_tokens':3,'output_tokens':2}];results.append({'form':name,'passed':True,'argv':a})
(root/'measurement-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
